from datetime import datetime, timedelta, timezone
import os, secrets, hashlib
from fastapi import FastAPI, Request, Form, Depends, HTTPException
from fastapi.responses import HTMLResponse, RedirectResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from starlette.middleware.sessions import SessionMiddleware
from sqlalchemy import create_engine, Column, Integer, String, DateTime, Boolean, ForeignKey, Text, UniqueConstraint
from sqlalchemy.orm import sessionmaker, declarative_base, relationship, Session

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./xtvilo.db")
ADMIN_USER = os.getenv("ADMIN_USER", "admin")
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "admin")
SECRET_KEY = os.getenv("SECRET_KEY", "change-me")
GRACE_DAYS = int(os.getenv("GRACE_DAYS", "7"))

engine = create_engine(DATABASE_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base = declarative_base()
app = FastAPI(title="XTVILO License Center", version="1.0")
app.add_middleware(SessionMiddleware, secret_key=SECRET_KEY)
templates = Jinja2Templates(directory="templates")

class Product(Base):
    __tablename__ = "products"
    id = Column(Integer, primary_key=True)
    name = Column(String(120), unique=True, nullable=False)
    code = Column(String(80), unique=True, nullable=False)
    version = Column(String(40), default="1.0")
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

class Customer(Base):
    __tablename__ = "customers"
    id = Column(Integer, primary_key=True)
    name = Column(String(160), nullable=False)
    email = Column(String(160), default="")
    phone = Column(String(80), default="")
    notes = Column(Text, default="")
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

class License(Base):
    __tablename__ = "licenses"
    id = Column(Integer, primary_key=True)
    license_key = Column(String(80), unique=True, nullable=False)
    customer_id = Column(Integer, ForeignKey("customers.id"))
    product_id = Column(Integer, ForeignKey("products.id"))
    status = Column(String(20), default="active")
    expires_at = Column(DateTime, nullable=True)
    max_devices = Column(Integer, default=1)
    channel_limit = Column(Integer, default=1)
    feature_flags = Column(Text, default="broadcast_switcher")
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    customer = relationship("Customer")
    product = relationship("Product")
    devices = relationship("Device", back_populates="license")

class Device(Base):
    __tablename__ = "devices"
    id = Column(Integer, primary_key=True)
    license_id = Column(Integer, ForeignKey("licenses.id"))
    hardware_id_hash = Column(String(128), nullable=False)
    device_name = Column(String(160), default="")
    first_seen = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    last_seen = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    last_ip = Column(String(80), default="")
    is_blocked = Column(Boolean, default=False)
    license = relationship("License", back_populates="devices")
    __table_args__ = (UniqueConstraint("license_id", "hardware_id_hash", name="uq_license_device"),)

Base.metadata.create_all(bind=engine)

def seed():
    db = SessionLocal()
    try:
        if not db.query(Product).filter_by(code="broadcast_switcher").first():
            db.add(Product(name="XTVILO Broadcast Switcher", code="broadcast_switcher", version="5.0"))
            db.commit()
    finally:
        db.close()
seed()

def get_db():
    db = SessionLocal()
    try: yield db
    finally: db.close()

def now(): return datetime.now(timezone.utc)
def is_admin(request): return request.session.get("admin") is True
def require_admin(request):
    if not is_admin(request): raise HTTPException(status_code=401, detail="Login required")
def make_key(): return "XTV-" + secrets.token_urlsafe(24).replace("-", "").replace("_", "")[:28].upper()
def hash_hw(x): return hashlib.sha256(x.strip().lower().encode()).hexdigest()

@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    if is_admin(request): return RedirectResponse("/admin", status_code=302)
    return templates.TemplateResponse("login.html", {"request": request, "error": ""})

@app.post("/login")
def login(request: Request, username: str = Form(...), password: str = Form(...)):
    if username == ADMIN_USER and password == ADMIN_PASSWORD:
        request.session["admin"] = True
        return RedirectResponse("/admin", status_code=302)
    return templates.TemplateResponse("login.html", {"request": request, "error": "Invalid username or password"})

@app.get("/logout")
def logout(request: Request):
    request.session.clear()
    return RedirectResponse("/", status_code=302)

@app.get("/admin", response_class=HTMLResponse)
def admin(request: Request, db: Session = Depends(get_db)):
    require_admin(request)
    return templates.TemplateResponse("admin.html", {
        "request": request,
        "products": db.query(Product).order_by(Product.id.desc()).all(),
        "customers": db.query(Customer).order_by(Customer.id.desc()).all(),
        "licenses": db.query(License).order_by(License.id.desc()).all(),
        "devices": db.query(Device).order_by(Device.last_seen.desc()).limit(100).all(),
    })

@app.post("/admin/products")
def add_product(request: Request, name: str = Form(...), code: str = Form(...), version: str = Form("1.0"), db: Session = Depends(get_db)):
    require_admin(request); db.add(Product(name=name, code=code, version=version)); db.commit()
    return RedirectResponse("/admin", status_code=302)

@app.post("/admin/customers")
def add_customer(request: Request, name: str = Form(...), email: str = Form(""), phone: str = Form(""), notes: str = Form(""), db: Session = Depends(get_db)):
    require_admin(request); db.add(Customer(name=name, email=email, phone=phone, notes=notes)); db.commit()
    return RedirectResponse("/admin", status_code=302)

@app.post("/admin/licenses")
def add_license(request: Request, customer_id: int = Form(...), product_id: int = Form(...), days: int = Form(365), max_devices: int = Form(1), channel_limit: int = Form(1), feature_flags: str = Form("broadcast_switcher"), db: Session = Depends(get_db)):
    require_admin(request)
    exp = now() + timedelta(days=days) if days > 0 else None
    db.add(License(license_key=make_key(), customer_id=customer_id, product_id=product_id, expires_at=exp, max_devices=max_devices, channel_limit=channel_limit, feature_flags=feature_flags))
    db.commit()
    return RedirectResponse("/admin", status_code=302)

@app.post("/admin/license/{license_id}/status")
def set_status(request: Request, license_id: int, status: str = Form(...), db: Session = Depends(get_db)):
    require_admin(request)
    lic = db.get(License, license_id)
    if lic: lic.status = status; db.commit()
    return RedirectResponse("/admin", status_code=302)

@app.post("/admin/device/{device_id}/block")
def block_device(request: Request, device_id: int, blocked: str = Form("true"), db: Session = Depends(get_db)):
    require_admin(request)
    d = db.get(Device, device_id)
    if d: d.is_blocked = (blocked == "true"); db.commit()
    return RedirectResponse("/admin", status_code=302)

@app.get("/health")
def health(): return {"ok": True, "service": "XTVILO License Center", "time": now().isoformat()}

@app.post("/api/v1/activate")
async def activate(request: Request, db: Session = Depends(get_db)):
    data = await request.json()
    license_key = data.get("license_key", "").strip()
    product_code = data.get("product_code", "").strip()
    hardware_id = data.get("hardware_id", "").strip()
    device_name = data.get("device_name", "")
    if not license_key or not product_code or not hardware_id:
        return JSONResponse({"ok": False, "reason": "missing_fields"}, status_code=400)
    lic = db.query(License).join(Product).filter(License.license_key == license_key, Product.code == product_code).first()
    if not lic: return {"ok": False, "reason": "invalid_license"}
    if lic.status != "active": return {"ok": False, "reason": lic.status}
    if lic.expires_at and lic.expires_at.replace(tzinfo=timezone.utc) < now():
        lic.status = "expired"; db.commit(); return {"ok": False, "reason": "expired"}
    hw = hash_hw(hardware_id)
    device = db.query(Device).filter_by(license_id=lic.id, hardware_id_hash=hw).first()
    if device and device.is_blocked: return {"ok": False, "reason": "device_blocked"}
    if not device:
        if db.query(Device).filter_by(license_id=lic.id).count() >= lic.max_devices:
            return {"ok": False, "reason": "device_limit_reached"}
        device = Device(license_id=lic.id, hardware_id_hash=hw, device_name=device_name, last_ip=request.client.host if request.client else "")
        db.add(device)
    device.last_seen = now(); device.last_ip = request.client.host if request.client else ""; db.commit()
    return {"ok": True, "license_key": lic.license_key, "status": lic.status, "expires_at": lic.expires_at.isoformat() if lic.expires_at else None, "channel_limit": lic.channel_limit, "feature_flags": lic.feature_flags.split(",") if lic.feature_flags else [], "grace_days": GRACE_DAYS}

@app.post("/api/v1/check")
async def check(request: Request, db: Session = Depends(get_db)):
    data = await request.json()
    license_key = data.get("license_key", "").strip()
    product_code = data.get("product_code", "").strip()
    hardware_id = data.get("hardware_id", "").strip()
    lic = db.query(License).join(Product).filter(License.license_key == license_key, Product.code == product_code).first()
    if not lic: return {"ok": False, "reason": "invalid_license"}
    if lic.status != "active": return {"ok": False, "reason": lic.status}
    if lic.expires_at and lic.expires_at.replace(tzinfo=timezone.utc) < now():
        lic.status = "expired"; db.commit(); return {"ok": False, "reason": "expired"}
    d = db.query(Device).filter_by(license_id=lic.id, hardware_id_hash=hash_hw(hardware_id)).first()
    if not d: return {"ok": False, "reason": "not_activated"}
    if d.is_blocked: return {"ok": False, "reason": "device_blocked"}
    d.last_seen = now(); d.last_ip = request.client.host if request.client else ""; db.commit()
    return {"ok": True, "status": lic.status, "expires_at": lic.expires_at.isoformat() if lic.expires_at else None, "channel_limit": lic.channel_limit, "feature_flags": lic.feature_flags.split(",") if lic.feature_flags else []}
